<?php
// no direct access
defined( '_VALID_MOS' ) or die( 'Restricted access' );

global $mosConfig_live_site, $database, $GLOBALS;

/**
* This string must match the Authentication Key, that you
* specified in the RealChat Control Center, Server Settings.
*/
$realchatAuthKey 	= $params->get( 'realchatAuthKey' );
/**
* Valid chat launching link generated with the Control Center.
*/
$realchatURL 		= $params->get( 'realchatURL' );
/**
* Use username or name.
*/
$name 				= $params->def( 'name', 		1 );
/**
* Show chat as popup
*/
$realchatPopup 		= $params->def( 'realchatPopup', 		1 );
/**
* Intergrate with community builder
*/
$communitybuilder	= $params->def( 'communitybuilder', 		1 );
/**
* Chat Now Text.
*/
$chatnow 		= $params->get( 'chatnow' );
/**
 * Generates a HMAC-protected link, based on the source link,
 * username, avatar and profile URLS, and authKey.
 */
function HMACLink($nickName, $profileURL, $avatarURL, $link, $authKey) {
	$cpID = substr(strrchr($link, ','), 1);
	$hmac = md5($cpID.rawurlencode($nickName).rawurlencode($profileURL).rawurlencode($avatarURL).$authKey.date('Ymd'));
	return $link."&nn=".rawurlencode($nickName)."&pu=".rawurlencode($profileURL)."&au=".rawurlencode($avatarURL)."&hmac=".$hmac;
}
?>
<script language="Javascript" type="text/javascript">
   <!--
   function realchatPopup(url, nn, pu, au, hmac) {
     var r = screen.height / screen.width;
     var w =  screen.width>800?1000:800;
     var h = Math.round(w*r);
     var c = function(s) { return encodeURIComponent(s).replace('!', '%21'); }
     var rcw = window.open(url + '&nn=' + c(nn) + '&pu=' + c(pu) +'&au=' + c(au) + '&hmac=' + hmac + '&cu=cw', 'rc','width='+w+',height='+h+',status=no,toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=yes');
     rcw.focus();
   }
   //-->
</script>
<?php
if ( $my->id ) {
	if ($realchatURL == "") {
		echo "Please edit realchatURL to complete the installation.";
	}
	else {
	/**
	* Nickname, avatar and profile URLs.
	* These are usually pulled from Joomla.
	*/
		if ( $name ) {
			$nickName = $my->name;
		} else {
			$nickName = $my->username;
		}
		$profileURL = "";
		$avatarURL = "";
		if ($communitybuilder){
			$userid = $my->id;
			$database->setQuery("SELECT id FROM #__menu WHERE link='index.php?option=com_comprofiler' AND type='components' AND published='1'");
			$base_url = $mosConfig_live_site."/index.php?option=com_comprofiler&Itemid=" . $database->loadResult();
			$database->setQuery("SELECT count(id) FROM #__comprofiler WHERE user_id='$userid'");
			$num = $database->loadResult();

			if ($num) {
				$profileURL = sefRelToAbs("$base_url&task=userProfile&user=$userid");
				$database->setQuery("SELECT avatar FROM #__comprofiler WHERE user_id='$userid'");
				$avatar = $database->loadResult();
				if (!empty($avatar)) {
					$avatarURL = $mosConfig_live_site."/images/comprofiler/".$avatar;
				}
			}

		}
		$hmacLink = HMACLink( $nickName, $profileURL, $avatarURL, $realchatURL, $realchatAuthKey );
		if ($realchatPopup) {
			$chatlink = "javascript:realchatPopup('".$realchatURL."','".$nickName."','".$profileURL."','".$avatarURL."','".$hmacLink."');";
		} else {
			$chatlink = $hmacLink;
		}

		echo '<a href="'.$chatlink.'">'.$chatnow.'</a>';

	}
}
else {
	echo "Login to chat";
}
?>