<?php

$lang = array (
'rc_pub_title'				=> "Chat",
'rc_pub_click_to_chat'		=> "Click to Chat",
'rc_pub_intro_popup'		=>	"Please click the link below to join our chat room. Please note that the chat page will open in a new window.",
'rc_pub_intro_direct'		=>	"Please click the link below to be taken directly to our chat room.",
'rc_pub_link_text'			=>	"Please click here to join the chat room.",

);
?>