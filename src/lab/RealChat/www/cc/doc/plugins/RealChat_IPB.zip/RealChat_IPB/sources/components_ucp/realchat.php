<?php
/*
+--------------------------------------------------------------------------
|   > RealChat Component v0.1
|   > 
|   > This file belongs in /sources/components_ucp/
+--------------------------------------------------------------------------
*/

if ( ! defined( 'IN_IPB' ) )
{
	print "<h1>Incorrect access</h1>You cannot access this file directly. If you have recently upgraded, make sure you upgraded 'admin.php'.";
	exit();
}

class components_ucp_realchat
{
	function ucp_build_menu()
	{
		$content = "";
		
		// lang
		$this->ipsclass->load_language('lang_realchat');
		
		$content .= $this->ipsclass->compiled_templates['skin_ucp']->menu_bar_new_link( "{$this->ipsclass->base_url}autocom=realchat",
																						$this->ipsclass->lang['rc_pub_click_to_chat'] );
		
		if ( $content )
		{
			return $this->ipsclass->compiled_templates['skin_ucp']->menu_bar_new_category( $this->ipsclass->lang['rc_pub_title'], $content );
		}
		else
		{
			return '';
		}
	}
}

?>