<?php
/*
+--------------------------------------------------------------------------
|   > RealChat Component v0.1
|   > 
|   > This file belongs in /sources/components_public/
+--------------------------------------------------------------------------
*/
if ( ! defined( 'IN_IPB' ) )
{
	print "<h1>Incorrect access</h1>You cannot access this file directly. If you have recently upgraded, make sure you upgraded 'admin.php'.";
	exit();
}

class component_public
{
	/**
	* IPSclass object
	*
	* @var object
	*/
	var $ipsclass;
	
	
	/**
	* Main function that's run from index.php
	*
	*/
	function run_component()
	{
        $this->ipsclass->load_language('lang_realchat');
    	$this->ipsclass->load_template('skin_realchat');
    	$this->base_url = $this->ipsclass->base_url;
    	
    	$this->page_title = "Chat";
    	$this->nav[] = "Chat";
    	
    	$chatlink = $this->chatLink();
    	
    	if ( $this->ipsclass->vars['realchatPopup'] == 1 )
    	{
	    	//popup
	    	$this->output .= $this->ipsclass->compiled_templates['skin_realchat']->popup($chatlink);
    	}
    	else
    	{
	    	// direct
			$this->output .= $this->ipsclass->compiled_templates['skin_realchat']->direct($chatlink);
    	}
    	
    	$this->ipsclass->print->add_output("$this->output");
        $this->ipsclass->print->do_output( array( 'TITLE' => $this->page_title, 'JS' => 0, NAV => $this->nav ) );
	}
	
	function chatLink()
	{
		
		if ( $this->ipsclass->member['id'] > 0 )
		{
		
			// Make sure everything is setup properly
			if ($this->ipsclass->vars['realchatURL'] == "" || $this->ipsclass->vars['realchatAuthKey'] == "") 
			{
				$this->ipsclass->Error( array( 'LEVEL' => 1, 'MSG' => 'invalid_use') );
			}
			
		    /**
		    * Nickname, avatar and profile URLs.
		    * These are usually pulled from the database.
		    */
		    $nickName = rawurlencode($this->ipsclass->member['members_display_name']);   // rawurlencode is important
		    
		    $profileURL = rawurlencode("{$this->base_url}showuser={$this->ipsclass->member['id']}");

		    // pull the member avatar details
			$avatar_details = $this->ipsclass->DB->build_and_exec_query( array( 'select' => 'avatar_type, avatar_location',
																  'from'   => 'member_extra',
																  'where'  => "id=".$this->ipsclass->member['id'] ) );
				
			$avatarURL = '';
			switch( $avatar_details['avatar_type'] )
			{
			case 'local':
				// blank, noavatar, or path to file
				if ($avatar_details['avatar_location'] != '' && $avatar_details['avatar_location'] != 'noavatar')
				{
					$avatarURL = $this->ipsclass->vars['board_url'] . "/" . $this->ipsclass->vars['AVATARS_URL'] . "/" . $avatar_details['avatar_location'];
				}				
				break;
			case 'upload':
				// filename
				$avatarURL = $this->ipsclass->vars['upload_url'] . "/" . $avatar_details['avatar_location'];
				break;
			case 'url':
				// path to file w/ http
				$avatarURL = $avatar_details['avatar_location'];
				break;
			}
			
			$avatarURL = rawurlencode($avatarURL);
			
		    /**
		    * This string must match the Authentication Key, that you
		    * specified in RealChat Control Center, Server Settings.
		    */
		    $authKey = $this->ipsclass->vars['realchatAuthKey'];
		     
		    /**
		    * Valid chat launching link generated with the Control Center.
		    */
		    $link = $this->ipsclass->vars['realchatURL'];
		     
		    /**
		    * The dedicated chat URL for this user.
		    * It should be used for Chat Now buttons, etc.
		    */
		    $hmacLink = $this->HMACLink( $nickName, $profileURL, $avatarURL, $link, $authKey );
		    
		    return $hmacLink;
	    }
	    else
	    {
		    // Not a member or not logged in
		    $this->ipsclass->Error( array( 'LEVEL' => 1, 'MSG' => 'no_permission') );
	    }
	}
	
    /**
    * Generates HMAC-protected link, based on source link,
    * username, avatar and profile URLS, authKey.
    */
    function HMACLink($nickName, $profileURL, $avatarURL, $link, $authKey) {
        $cpID = substr(strrchr($link, ','), 1);
        $hmac = md5($cpID.$nickName.$profileURL.$avatarURL.$authKey.date('Ymd'));
        
		return $this->ipsclass->vars['realchatPopup'] ? "javascript:realchatPopup('".$this->ipsclass->vars['realchatURL']."','".$nickName."','".$profileURL."','".$avatarURL."','".$hmac."');" : $link."&nn=".$nickName."&pu=".$profileURL."&au=".$avatarURL."&hmac=".$hmac;
    }
}
?>