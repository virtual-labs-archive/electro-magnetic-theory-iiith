<?php
/**
 * This string must match the Authentication Key, that you
 * specified in RealChat Control Center, Server Settings.
 * Should look like: "VAMNRADQDGDFTVKH"
 */
$realchatAuthKey = "";

/**
 * Valid chat launching link generated with RealChat Control Center.
 * Should look like: "http://host:port/?0,0,0,0,0"
 */
$realchatURL = "";

/**
 * Should the chat open in new pop up window?
 */
$realchatPopup = false;

/** Do not modify below this point **/
function chatLink() {
	global $realchatAuthKey, $realchatURL, $realchatPopup, $vbulletin;
	if ($realchatURL == "") return "javascript:alert('Please edit realchat.php to complete the installation.')";

	if ( $vbulletin->userinfo['userid'] != 0 ) {
		$nickName = $vbulletin->userinfo[username];
		$profileURL = $vbulletin->options[bburl]."/member.php?u=".$vbulletin->userinfo[userid];
		$avatarURL = $vbulletin->options[bburl]."/image.php?u=".$vbulletin->userinfo[userid];
		$cpID = substr(strrchr($realchatURL, ','), 1);
		$hmac = md5($cpID.rawurlencode($nickName).rawurlencode($profileURL).rawurlencode($avatarURL).$realchatAuthKey.date('Ymd'));
		$u = "nn=".rawurlencode($nickName)."&pu=".rawurlencode($profileURL)."&au=".rawurlencode($avatarURL)."&hmac=".$hmac."&cu=".$bbRoot;
		return $realchatPopup ? "javascript:realchatPopup('".$realchatURL."','".$nickName."','".$profileURL."','".$avatarURL."','".$hmac."');" : $realchatURL."&".$u;
	}
	else {
		return $vbulletin->options[bburl]."/login.php";
	}
}
$chatLink = chatlink();
?>