<?php
/*
+--------------------------------------------------------------------------
|   > RealChat Component v0.1
|   > 
|   > This file belongs in /sources/components_acp/
+--------------------------------------------------------------------------
*/
if ( ! defined( 'IN_ACP' ) )
{
	print "<h1>Incorrect access</h1>You cannot access this file directly. If you have recently upgraded, make sure you upgraded 'admin.php'.";
	exit();
}

class ad_realchat
{
	# Global
	var $ipsclass;
	var $html;

	function auto_run()
	{
		// Kill globals
		$tmp_in = array_merge( $_GET, $_POST, $_COOKIE );
		
		foreach ( $tmp_in as $k => $v )
		{
			unset($$k);
		}

		switch( $this->ipsclass->input['code'] )
		{
			case 'settings':
				$this->show_settings();
				break;
			case 'install':
				$this->show_installer();
				break;
			case 'run_installer':
				$this->run_installer();
				break;
			case 'run_uninstaller':
				$this->run_uninstaller();
				break;
			default:
				$this->show_settings();
		}
	}
	
	function show_installer()
	{
		//NOTE to anyone reading this: I'm putting the HTML for the install routine in this file.
		// I'm doing this because otherwise, the installer html would be loaded into memory every 
		// time the chat page was accessed-- hardly efficient. Instead, I'll make this file a bit
		// bigger, which is OK-- it should only need to be accessed once when the component is 
		// installed. You shouldn't need to edit the HTML on the installer. So without further
		// delay.... I present... the installer routine. (It's not a big deal, really)

		// Settings?
		if ( isset($this->ipsclass->vars['realchatURL']) && isset($this->ipsclass->vars['realchatAuthKey']) ) $has_settings = TRUE;
		
		// Templates?
		// required template list
		$default_templates = array( 'direct'	=> 0,
									'popup'	=> 0 );
		
		$this->ipsclass->DB->query("SELECT * FROM ibf_skin_templates WHERE group_name = 'skin_realchat'");
		while ($row = $this->ipsclass->DB->fetch_row())
		{
			$default_templates[ $row['func_name'] ] = 1;
		}
		
		if (is_null(array_search(0, $default_templates))) $has_templates = TRUE;
		
		if (!$has_settings || !has_templates)
		{
			// no settings or templates = not installed
			$this->ipsclass->admin->page_title  = "Component Not Installed";
			$this->ipsclass->admin->page_detail = "<p style='font-size: 12px; font-weight: bold;'><span style='color: red;'>Realchat is not installed.</span><br /><br />To install Realchat, please click the button below.</p>";
			$this->ipsclass->html .= "<span class='fauxbutton'><a href='{$this->ipsclass->base_url}&amp;section=components&amp;act=realchat&amp;code=run_installer' style='font-weight: bold;'>Install</a></span>";
		}
		else
		{
			// we have settings and templates, we're already installed
			$this->ipsclass->admin->page_title  = "Component Installed";
			$this->ipsclass->admin->page_detail = "<p style='font-size: 12px; font-weight: bold;'><span style='color: green;'>RealChat is currently installed.</span><br /><br />If you would like to uninstall RealChat, you may do so by clicking the button below.<br /><br /><span style='color: red'>WARNING: Clicking the button below will uninstall RealChat.<br /><br />There will be no further warnings.</span></p>";
			$this->ipsclass->html .= "<span class='fauxbutton'><a href='{$this->ipsclass->base_url}&amp;section=components&amp;act=realchat&amp;code=run_uninstaller' style='font-weight: bold;'>Uninstall</a></span>";
		}

		$this->ipsclass->admin->output();
	}
	
	function run_installer()
	{
		// To install, we have to:
		// - add skin bits.
		// - add settings
		// - enable component
		
		// require api files
		require_once( ROOT_PATH . 'sources/api/api_core.php' );
		require_once( ROOT_PATH . 'sources/api/api_skins.php' );
		require_once( ROOT_PATH . 'sources/api/api_settings.php' );
		require_once( ROOT_PATH . 'sources/api/api_components.php' );
		
		// insert skin bits
		$api           =  new api_skins();
		$api->ipsclass =& $this->ipsclass;
		$api->api_init();
		$api->skin_add_bits(ROOT_PATH.'sources/components_acp/realchat_install/realchat_templates.xml');
		$api->skin_rebuild_caches(1);
		
		// insert settings
		$api			= new api_settings();
		$api->ipsclass =& $this->ipsclass;
		$api->api_init();
		$api->update_settings(ROOT_PATH.'sources/components_acp/realchat_install/realchat_settings.xml');
		
		// enable component
		$api =  new api_components();
		$api->ipsclass =& $this->ipsclass;
		$api->api_init();
		$api->acp_component_enable( 'realchat' );
		
		$this->ipsclass->boink_it($this->ipsclass->base_url."&amp;section=components&amp;act=realchat");
	}
	
	function run_uninstaller()
	{
		// To uninstall this mod, we have to:
		// - Delete Skin bits.
		// - Delete settings
		// - Rebuild settings cache
		// - Deactivate the component
		
		// Delete skin
		$this->ipsclass->DB->query("DELETE FROM ibf_skin_templates WHERE group_name = 'skin_realchat'");
		
		// Delete settings
		$this->ipsclass->DB->query("DELETE FROM ibf_conf_settings WHERE conf_key = 'realchatPopup'");
		$this->ipsclass->DB->query("DELETE FROM ibf_conf_settings WHERE conf_key = 'realchatURL'");
		$this->ipsclass->DB->query("DELETE FROM ibf_conf_settings WHERE conf_key = 'realchatAuthKey'");
		
		// Delete setting group
		$this->ipsclass->DB->query("DELETE FROM ibf_conf_settings_titles WHERE conf_title_keyword = 'realchat'");
		
		// Recache
		// settings lib
		require_once( ROOT_PATH.'sources/action_admin/settings.php' );
		$settings           =  new ad_settings();
		$settings->ipsclass =& $this->ipsclass;
		
		$settings->setting_rebuildcache();
		
		//Disable component
		// require api files
		require_once( ROOT_PATH . 'sources/api/api_core.php' );
		require_once( ROOT_PATH . 'sources/api/api_components.php' );
		$api =  new api_components();
		$api->ipsclass =& $this->ipsclass;
		$api->api_init();
		$api->acp_component_disable( 'realchat' );
		
		$this->ipsclass->boink_it($this->ipsclass->base_url."&amp;section=components&amp;act=realchat");
	}
	
	function show_settings()
	{

		//make sure we're installed
		if (!isset($this->ipsclass->vars['realchatURL']) || !isset($this->ipsclass->vars['realchatAuthKey']))
		{
			$this->ipsclass->admin->page_detail = "This component has not yet been installed. <br /><br />Please click Installer at the left to install this component.";
			$this->ipsclass->admin->page_title  = "Component Not Installed";
			$this->ipsclass->admin->output();
		}
		
		$this->ipsclass->admin->page_title  = "RealChat Configuration";
		$this->ipsclass->admin->page_detail = "Please edit the configuration below to suit your preferences and your RealChat installation.";

		// settings lib
		require_once( ROOT_PATH.'sources/action_admin/settings.php' );
		$settings           =  new ad_settings();
		$settings->ipsclass =& $this->ipsclass;
		
		$settings->get_by_key        = 'realchat';
		$settings->return_after_save = 'section=components&amp;act=realchat&amp;code=settings';
		
		$settings->setting_view();
	}
}

?>